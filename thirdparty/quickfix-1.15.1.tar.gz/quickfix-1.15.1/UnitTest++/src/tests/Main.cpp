#include "../UnitTest++.h"
#include "../TestReporterStdout.h"


int main(int, char const *[])
{
    return UnitTest::RunAllTests();
}
